# 2.py 网页可视化

这个目录提供了一个仿照 `/home/xlz/ros2/yifu/python` 风格的网页，用来可视化 `2.py` 发布的数据。

## 对应话题

- `/sensor/capacitance`
- `/sensor/acceleration_raw`
- `/sensor/gyroscope_raw`
- `/sensor/magnetic_raw`

## 启动

先确保 `2.py` 已经在发布 ROS2 数据，然后启动网页：

```bash
cd /home/xlz/ros2/yifu/yifu_ban/yifu/python
pip install -r requirements.txt
python3 web_visualizer.py
```

浏览器打开：`http://localhost:5013`

## 页面内容

- 8 路 IMU 通道切换
- 原始加速度 / 角速度 / 磁场曲线
- 8 路 IMU 最新值总览表
- 10 路电容折线图和最新值表
